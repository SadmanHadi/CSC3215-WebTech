document.getElementById("registrationForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const fullname = document.getElementById("fullname").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const dob = document.getElementById("dob").value;
    const country = document.getElementById("country").value;
    const gender = document.querySelector('input[name="gender"]:checked');
    const comments = document.getElementById("comments").value.trim();
    const termsAccepted = document.getElementById("terms").checked;
  
    const nameRegex = /^[a-zA-Z\s]+$/;
    const emailRegex = /^\d{2}-\d{5}-[1-3]@student\.aiub\.edu$/;
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;
  
    let errors = [];
  
    if (!nameRegex.test(fullname)) {
      errors.push("Full Name should contain only letters and spaces.");
    }
  
    if (!emailRegex.test(email)) {
      errors.push("Email must be a valid xx-xxxxx-x@student.aiub.edu address.");
    }
  
    if (!passwordRegex.test(password)) {
      errors.push("Password must be at least 6 characters, include letters and numbers.");
    }
  
    if (password !== confirmPassword) {
      errors.push("Passwords do not match.");
    }
  
    if (!gender) {
      errors.push("Please select a gender.");
    }
  
    if (!dob) {
      errors.push("Please select your date of birth.");
    }
  
    if (!country) {
      errors.push("Please select a country.");
    }
  
    if (!termsAccepted) {
      errors.push("You must agree to the Terms and Conditions.");
    }
  
    const displayDiv = document.getElementById("userDisplay");
  
    if (errors.length > 0) {
      displayDiv.innerHTML = `<p style="color:red;"><strong>${errors.join("<br>")}</strong></p>`;
    } else {
      displayDiv.innerHTML = `
        <hr>
        <p><strong>Name:</strong> ${fullname}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>DOB:</strong> ${dob}</p>
        <p><strong>Country:</strong> ${country}</p>
        <p><strong>Gender:</strong> ${gender.value}</p>
        <p><strong>Comments:</strong> ${comments || "None"}</p>
        <hr>
        <p style="color:green;"><strong>Registration successful!</strong></p>
      `;
      this.reset();
    }
  });
  